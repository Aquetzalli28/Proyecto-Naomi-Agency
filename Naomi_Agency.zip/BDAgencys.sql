CREATE DATABASE DbConnectionAgency;
USE DbConnectionAgency;
create table Users
(
IdUser int auto_increment primary key,
Name varchar (500),
Email varchar (300),
Password varchar (200),
CreationDate date,
InactiveDate date ,
CreationUserId int
);
INSERT INTO Users (Name, Email, Password, CreationDate, InactiveDate, CreationUserId)
VALUES
('Naomi', 'cepedanaomi81@gmail.com', '280124', '2024-12-07', NULL, 1); 
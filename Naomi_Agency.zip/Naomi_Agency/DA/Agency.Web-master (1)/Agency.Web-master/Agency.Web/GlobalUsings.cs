﻿global using Microsoft.AspNetCore.Mvc;
global using System;
global using System.Security.Claims;
global using Microsoft.AspNetCore.Authentication;
global using Microsoft.AspNetCore.Authorization;
global using Agency.Web.ViewModels;